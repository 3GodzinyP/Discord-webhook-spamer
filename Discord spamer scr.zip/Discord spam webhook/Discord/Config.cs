﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dicord
{
    class Config
    {
        public static string AvatarUrl = "https://cdn.discordapp.com/attachments/992551603863289888/1007380626095214592/unnamed.png"; // Avatar Link
    }
}
